package com.restassuredapi.base;

import org.apache.log4j.xml.DOMConfigurator;
import org.json.JSONObject;
import org.testng.ITestListener;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentTest;
import com.restassuredapi.utility.ExtentManager;

import static io.restassured.RestAssured.*;

import java.io.FileInputStream;
import java.lang.reflect.Method;
import java.util.Properties;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class BaseTest implements ITestListener {

	public ExtentManager extent;
	protected RequestSpecification spec;
	public static Properties prop;
	public ExtentTest test;

	public BaseTest() {
		extent = new ExtentManager();
	}

	// loadConfig method is to load the configuration
	@BeforeSuite
	public void loadConfig() {
		
		extent.setExtent();
		DOMConfigurator.configure("log4j.xml");
		//test=extent.getExtentTest();
		try {
			prop = new Properties();
			FileInputStream fis = new FileInputStream(
					System.getProperty("user.dir") + "\\config\\globalconfig.properties");
			prop.load(fis);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@BeforeMethod
	public void setup(Method method) {
		test=extent.startTest(method.getName());
		spec = new RequestSpecBuilder().setBaseUri(prop.getProperty("baseUri")).build();
	}

	protected Response createBooking() {
		// create JSON body
		JSONObject body = new JSONObject();
		body.put("firstname", "Arun");
		body.put("lastname", "Yadav");
		body.put("totalprice", 1000);
		body.put("depositpaid", true);

		JSONObject bookingdates = new JSONObject();
		bookingdates.put("checkin", "2022-10-25");
		bookingdates.put("checkout", "2022-10-27");
		body.put("bookingdates", bookingdates);
		body.put("additionalneeds", "Breakfast");

		// Get reponse
		Response response = RestAssured.given(spec).contentType(ContentType.JSON).body(body.toString())
				.post("/booking");
		return response;
	}
	
	@AfterMethod
	public void tearDown(Method method) {
		extent.endTest(method.getName());
		
	}
	

	@AfterSuite()
	public void afterSuite() {
			
		extent.extent.flush();
	}
	

}
