package com.restassuredapi.utility;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

/**
 * @author aruny: ExtentManager class is used for Extent Report
 * 
 */
public class ExtentManager {

	public ExtentHtmlReporter htmlReporter;
	public ExtentReports extent;
	public ExtentTest test;
	static String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());

	public void setExtent() {
		htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir") + "/Reports/ExtentReport/"
				+ "TestAutomationReport_" + timeStamp + ".html");
		htmlReporter.loadXMLConfig(System.getProperty("user.dir") + "/extent-config.xml");
		htmlReporter.config().setDocumentTitle("API Automation Test Report" + "_" + timeStamp);
		htmlReporter.config().setReportName("Rest Assured API Automation Report");
		// htmlReporter.config().setTheme(Theme.DARK);
		this.extent = new ExtentReports();
		this.extent.attachReporter(htmlReporter);

		this.extent.setSystemInfo("HostName", "Arun's Laptop");
		this.extent.setSystemInfo("ProjectName", "Rest API Automation");
		this.extent.setSystemInfo("SDET", "Arun Yadav");
		this.extent.setSystemInfo("OS", "Win10");
		//test=extent.createTest("TestCaseName");
	}

	public ExtentTest startTest(String TestCaseName) {
		Log.info("extent=" + this.extent);
		Log.info("****************************************************************************************");
		Log.info("****************************************************************************************");
		Log.info("$$$$$$$$                 " + TestCaseName + "       $$$$$$$$");
		Log.info("****************************************************************************************");
		Log.info("****************************************************************************************");
		test=this.extent.createTest(TestCaseName);
       return test;
	}

	public ExtentTest getExtentTest() {
		return test;
	}

	public void endTest(String TestCaseName) {
		Log.info("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
		Log.info("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
		Log.info("XXXXXXXXXXXXXXXXXXXXXXXXXX           " + TestCaseName + "   -E---N---D-             XXXXXXXXXXXXXXXXXXXXXXXXX");
		Log.info("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
		Log.info("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
		
	}

}