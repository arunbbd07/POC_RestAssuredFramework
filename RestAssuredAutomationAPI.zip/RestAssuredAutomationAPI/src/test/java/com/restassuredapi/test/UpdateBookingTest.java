package com.restassuredapi.test;

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.Status;
import com.restassuredapi.base.BaseTest;
import com.restassuredapi.utility.ExtentManager;
import com.restassuredapi.utility.Log;

import io.restassured.RestAssured;
import io.restassured.filter.log.LogDetail;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class UpdateBookingTest extends BaseTest {

	@Test()
	public void updateBookingTest() {
		String testname = new Object() {
		}.getClass().getEnclosingMethod().getName();
		Log.startTestCase(testname);
		test.log(Status.INFO, "Test started with name : " + testname);
		Response response = createBooking();
		test.log(Status.INFO, "<b>Create Booking Response Body</b>" + "<pre>" + response.asPrettyString() + "</pre>");
		response.print();

		// Verify response 200
		Assert.assertEquals(response.getStatusCode(), 200, "Status code should be 200, but it's not");
		if (response.getStatusCode() == 200) {
			test.log(Status.PASS, "Test is passed with status code " + response.getStatusCode());
		} else {
			{
				test.log(Status.FAIL, "Test is failed with status code " + response.getStatusCode());
			}
		}

		// Get bookingId of new booking
		int bookingid = response.jsonPath().getInt("bookingid");

		// Create JSON body
		JSONObject body = new JSONObject();
		body.put("firstname", "Gunjan");
		body.put("lastname", "Yadav");
		body.put("totalprice", 1000);
		body.put("depositpaid", true);

		JSONObject bookingdates = new JSONObject();
		bookingdates.put("checkin", "2022-10-25");
		bookingdates.put("checkout", "2022-10-29");
		body.put("bookingdates", bookingdates);
		body.put("additionalneeds", "Dinner");

		// Update booking
		Response responseUpdate = RestAssured.given(spec).auth().preemptive()
				.basic(prop.getProperty("username"), prop.getProperty("password")).contentType(ContentType.JSON)
				.body(body.toString()).put("/booking/" + bookingid);
		responseUpdate.print();

		test.log(Status.INFO,
				"<b>Updated Booking Response Body</b>" + "<pre>" + responseUpdate.asPrettyString() + "</pre>");

		// Verify All fields
		SoftAssert softAssert = new SoftAssert();
		String actualFirstName = responseUpdate.jsonPath().getString("firstname");
		softAssert.assertEquals(actualFirstName, "Gunjan", "firstname in response is not expected");
		test.log(Status.INFO, "<b> First Name</b> :" + actualFirstName);

		String actualLastName = responseUpdate.jsonPath().getString("lastname");
		softAssert.assertEquals(actualLastName, "Yadav", "lastname in response is not expected");
		test.log(Status.INFO, "<b> Last Name</b> :" + actualLastName);

		int price = responseUpdate.jsonPath().getInt("totalprice");
		softAssert.assertEquals(price, 1000, "totalprice in response is not expected");
		test.log(Status.INFO, "<b>Price</b> :" + price);

		boolean depositpaid = responseUpdate.jsonPath().getBoolean("depositpaid");
		softAssert.assertTrue(depositpaid, "depositpaid should be True, but it's not");
		test.log(Status.INFO, "<b>Deposit Paid</b> :" + depositpaid);

		String actualCheckin = responseUpdate.jsonPath().getString("bookingdates.checkin");
		softAssert.assertEquals(actualCheckin, "2022-10-25", "checkin in response is not expected");
		test.log(Status.INFO, "<b>Checkin</b> :" + actualCheckin);

		String actualCheckout = responseUpdate.jsonPath().getString("bookingdates.checkout");
		softAssert.assertEquals(actualCheckout, "2022-10-29", "checkout in response is not expected");
		test.log(Status.INFO, "<b>Checkout</b> :" + actualCheckout);

		String actualAdditionalneeds = responseUpdate.jsonPath().getString("additionalneeds");
		softAssert.assertEquals(actualAdditionalneeds, "Dinner", "additionalneeds in response is not expected");
		test.log(Status.INFO, "<b>Additional Needs</b> :" + actualAdditionalneeds);
		
		softAssert.assertAll();
		Log.endTestCase(testname);
		test.log(Status.INFO, "Test ended with name : " + testname);
		extent.endTest(testname);
	}

}
