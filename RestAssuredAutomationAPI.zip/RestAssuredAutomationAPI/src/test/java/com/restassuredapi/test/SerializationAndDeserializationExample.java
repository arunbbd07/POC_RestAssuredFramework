package com.restassuredapi.test;

import java.io.File;

import com.fasterxml.jackson.databind.ObjectMapper;

public class SerializationAndDeserializationExample {

	public static void main(String[] args) {
		SerializationAndDeserializationExample obj = new SerializationAndDeserializationExample();
		obj.SerializationExample();
		obj.DeserializationExample();
	}

	// Convert Java Object (POJO) to JSON for serialization
	public void SerializationExample() {
		try {
			ObjectMapper objectMapper = new ObjectMapper();

			Employee emp = new Employee("Arun", "Delhi", "SDET", 1001);

			objectMapper.writeValue(new File(System.getProperty("user.dir") + "/Reports/emp.json"), emp);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Convert JSON to Java Object (POJO) for deserialization
	public void DeserializationExample() {
		try {
			ObjectMapper objectMapper = new ObjectMapper();

			String empjson = "{\"name\":\"Arun\",\"city\":\"Delhi\",\"job\":\"SDET\",\"salary\":1001}";
			Employee empJavaObject = objectMapper.readValue(empjson, Employee.class);
			System.out.println("Name : " + empJavaObject.getName());
			System.out.println("City : " + empJavaObject.getCity());
			System.out.println("Job : " + empJavaObject.getJob());
			System.out.println("Salary : " + empJavaObject.getSalary());

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}