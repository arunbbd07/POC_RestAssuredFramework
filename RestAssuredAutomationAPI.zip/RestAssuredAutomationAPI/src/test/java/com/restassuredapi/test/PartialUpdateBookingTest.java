package com.restassuredapi.test;

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.Status;
import com.restassuredapi.base.BaseTest;
import com.restassuredapi.utility.ExtentManager;
import com.restassuredapi.utility.Log;

import io.restassured.RestAssured;
import io.restassured.filter.log.LogDetail;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class PartialUpdateBookingTest extends BaseTest {

	@Test()
	public void partialUpdateBookingTest() {
		String testname = new Object() {
		}.getClass().getEnclosingMethod().getName();
		Log.startTestCase(testname);
		test.log(Status.INFO, "Test started with name : " + testname);
		Response response = createBooking();
		test.log(Status.INFO, "<b>Create Booking Response Body</b>" + "<pre>" + response.asPrettyString() + "</pre>");
		response.print();

		// Verify response 200
		Assert.assertEquals(response.getStatusCode(), 200, "Status code should be 200, but it's not");
		if (response.getStatusCode() == 200) {
			test.log(Status.PASS, "Test is passed with status code " + response.getStatusCode());
		} else {
			{
				test.log(Status.FAIL, "Test is failed with status code " + response.getStatusCode());
			}
		}

		// Get bookingId of new booking
		int bookingid = response.jsonPath().getInt("bookingid");

		// Create JSON body
		JSONObject body = new JSONObject();
		body.put("firstname", "Gunjan");

		JSONObject bookingdates = new JSONObject();
		bookingdates.put("checkin", "2022-10-25");
		bookingdates.put("checkout", "2022-10-28");

		body.put("bookingdates", bookingdates);

		// PartialUpdate booking
		Response responseUpdate = RestAssured.given(spec).auth().preemptive()
				.basic(prop.getProperty("username"), prop.getProperty("password")).contentType(ContentType.JSON)
				.body(body.toString()).patch("/booking/" + bookingid);
		responseUpdate.print();

		test.log(Status.INFO,
				"<b>Updated Booking Response Body</b>" + "<pre>" + responseUpdate.asPrettyString() + "</pre>");
		// Verifications
		// Verify response 201
		Assert.assertEquals(responseUpdate.getStatusCode(), 200, "Status code should be 200, but it's not.");
		test.log(Status.INFO, "<b>Response Code</b> : " + responseUpdate.getStatusCode());

		// Verify All fields
		SoftAssert softAssert = new SoftAssert();
		String actualFirstName = responseUpdate.jsonPath().getString("firstname");
		softAssert.assertEquals(actualFirstName, "Gunjan", "firstname in response is not expected");
		test.log(Status.INFO, "<b> Updated First Name</b> :" + actualFirstName);

		String actualCheckin = responseUpdate.jsonPath().getString("bookingdates.checkin");
		softAssert.assertEquals(actualCheckin, "2022-10-25", "checkin in response is not expected");
		test.log(Status.INFO, "<b> Updated Checkin</b> :" + actualCheckin);

		String actualCheckout = responseUpdate.jsonPath().getString("bookingdates.checkout");
		softAssert.assertEquals(actualCheckout, "2022-10-28", "checkout in response is not expected");
		test.log(Status.INFO, "<b>Updated Checkout</b> :" + actualCheckout);
		softAssert.assertAll();
		Log.endTestCase(testname);
		test.log(Status.INFO, "Test ended with name : " + testname);
		extent.endTest(testname);
	}

}
