package com.restassuredapi.test;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.Status;
import com.restassuredapi.base.BaseTest;
import com.restassuredapi.utility.ExtentManager;
import com.restassuredapi.utility.Log;

import io.restassured.filter.log.LogDetail;
import io.restassured.response.Response;

public class CreateBookingTest extends BaseTest {

	@Test
	public void createBookingTest() {
		String testname = new Object() {}.getClass().getEnclosingMethod().getName();
		Log.startTestCase(testname);
		test.log(Status.INFO, "Test started with name : " + testname);
		Response response = createBooking();
		test.log(Status.INFO, "<b>Create Booking Response Body</b>" + "<pre>" + response.asPrettyString() + "</pre>");
		response.print();
		
		// Verify response 200
		Assert.assertEquals(response.getStatusCode(), 200, "Status code should be 200, but it's not");
		if (response.getStatusCode() == 200) {
			test.log(Status.PASS, "Test is passed with status code " + response.getStatusCode());
		} else {
			{
				test.log(Status.FAIL, "Test is failed with status code " + response.getStatusCode());
			}
		}
        
		// Verify All fields
		SoftAssert softAssert = new SoftAssert();
		String actualFirstName = response.jsonPath().getString("booking.firstname");
		softAssert.assertEquals(actualFirstName, "Arun", "firstname in response is not expected");
		test.log(Status.INFO, "<b> First Name</b> :"+actualFirstName);	
		
		String actualLastName = response.jsonPath().getString("booking.lastname");
		softAssert.assertEquals(actualLastName, "Yadav", "lastname in response is not expected");
		test.log(Status.INFO, "<b> Last Name</b> :"+actualLastName);
		
		int price = response.jsonPath().getInt("booking.totalprice");
		softAssert.assertEquals(price, 1000, "totalprice in response is not expected");
		test.log(Status.INFO, "<b>Price</b> :"+price);
		
		boolean depositpaid = response.jsonPath().getBoolean("booking.depositpaid");
		softAssert.assertTrue(depositpaid, "depositpaid should be True, but it's not");
		test.log(Status.INFO, "<b>Deposit Paid</b> :"+depositpaid);

		String actualCheckin = response.jsonPath().getString("booking.bookingdates.checkin");
		softAssert.assertEquals(actualCheckin, "2022-10-25", "checkin in response is not expected");
		test.log(Status.INFO, "<b>Checkin</b> :"+actualCheckin);

		String actualCheckout = response.jsonPath().getString("booking.bookingdates.checkout");
		softAssert.assertEquals(actualCheckout, "2022-10-27", "checkout in response is not expected");
		test.log(Status.INFO, "<b>Checkout</b> :"+actualCheckout);
		
		String actualAdditionalneeds = response.jsonPath().getString("booking.additionalneeds");
		softAssert.assertEquals(actualAdditionalneeds, "Breakfast", "additionalneeds in response is not expected");
		test.log(Status.INFO, "<b>Additional Needs</b> :"+actualAdditionalneeds);
		
		softAssert.assertAll();
		Log.endTestCase(testname);
		test.log(Status.INFO, "Test ended with name : " + testname);
		extent.endTest(testname);
	}

}
