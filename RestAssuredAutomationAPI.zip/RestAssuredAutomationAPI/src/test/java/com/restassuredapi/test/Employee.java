package com.restassuredapi.test;

public class Employee {

	private String name;
	private String city;
	private String job;
	private int salary;

	public Employee() {

	}

	public Employee(String name, String city, String job, int salary) {
		this.name = name;
		this.city = city;
		this.job = job;
		this.salary = salary;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

}
