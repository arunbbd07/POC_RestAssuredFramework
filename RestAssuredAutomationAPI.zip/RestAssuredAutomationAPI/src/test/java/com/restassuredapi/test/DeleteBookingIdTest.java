package com.restassuredapi.test;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.Status;
import com.restassuredapi.base.BaseTest;
import com.restassuredapi.utility.ExtentManager;
import com.restassuredapi.utility.Log;

import io.restassured.RestAssured;
import io.restassured.filter.log.LogDetail;
import io.restassured.response.Response;

public class DeleteBookingIdTest extends BaseTest {

	@Test()
	public void deleteBookingIdTest() {
		String testname = new Object() {}.getClass().getEnclosingMethod().getName();
		Log.startTestCase(testname);
		test.log(Status.INFO, "Test started with name : " + testname);
		Response response = createBooking();
		test.log(Status.INFO, "<b>Create Booking Response Body</b>" + "<pre>" + response.asPrettyString() + "</pre>");
		response.print();

		// Verify response 200
		Assert.assertEquals(response.getStatusCode(), 200, "Status code should be 200, but it's not");
		if (response.getStatusCode() == 200) {
			test.log(Status.PASS, "Test is passed with status code " + response.getStatusCode());
		} else {
			{
				test.log(Status.FAIL, "Test is failed with status code " + response.getStatusCode());
			}
		}

		// Get bookingId of new booking
		int bookingid = response.jsonPath().getInt("bookingid");

		// Delete booking
		Response responseDelete = RestAssured.given(spec).auth().preemptive().basic(prop.getProperty("username"), prop.getProperty("password"))
				.delete("/booking/" + bookingid);
		responseDelete.print();
		test.log(Status.INFO, "<b>Delete Booking Response Body</b>" + "<pre>" + responseDelete.asPrettyString() + "</pre>");
		// Verifications
		// Verify response 201
		Assert.assertEquals(responseDelete.getStatusCode(), 201, "Status code should be 201, but it's not.");
		test.log(Status.INFO, "<b>Response Code</b> : "  + responseDelete.getStatusCode() );
		
		Response responseGet = RestAssured.get(prop.getProperty("baseUri")+"/booking/" + bookingid);
		responseGet.print();

		Assert.assertEquals(responseGet.getBody().asString(), "Not Found", "Body should be 'Not Found', but it's not.");
		test.log(Status.INFO, "<b>Earlier Created Booking Response Body</b>" + "<pre>" + responseGet.asPrettyString() + "</pre>");
		Log.endTestCase(testname);
		test.log(Status.INFO, "Test ended with name : " + testname);
		extent.endTest(testname);
	}

}
