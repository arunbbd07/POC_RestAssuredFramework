package com.restassuredapi.test;

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.Status;
import com.restassuredapi.base.BaseTest;
import com.restassuredapi.utility.ExtentManager;
import com.restassuredapi.utility.Log;

import static io.restassured.RestAssured.*;

import io.restassured.RestAssured;
import io.restassured.filter.log.LogDetail;
import io.restassured.http.ContentType;
import io.restassured.http.Cookie;
import io.restassured.http.Cookies;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;

public class HealthCheckTest extends BaseTest {

	@Test
	public void healthCheckTest() {
		given().spec(spec).when().get("/ping").then().assertThat().statusCode(201);
	}

	@Test
	public void headersAndCookiesTest() {
		Header someHeader = new Header("some_name", "Some_value");
		spec.header(someHeader);

		Cookie someCookie = new Cookie.Builder("some cookie", "some cookie value").build();
		spec.cookie(someCookie);

		Response response = RestAssured.given(spec).cookie("Test cookie name", "Test cookie value")
				.header("Test header name", "Test header Value").log().all().get("/ping");
		
		test.log(Status.INFO,
				"<b>Response Body</b>" + "<pre>" + response.asPrettyString() + "</pre>");
		// Get headers
		Headers headers = response.getHeaders();
		System.out.println("Headers: " + headers);
		test.log(Status.INFO,
				"<b>Headers</b>" + "<pre>" + headers + "</pre>");
		
		Header serverHeader1 = headers.get("Server");
		System.out.println(serverHeader1.getName() + ": " + serverHeader1.getValue());
		test.log(Status.INFO,
				"<b>ServerHeader1</b>" + "<pre>" + serverHeader1.getName()+" : "+serverHeader1.getValue() + "</pre>");

		String serverHeader2 = response.getHeader("Server");
		System.out.println("Server: " + serverHeader2);
		test.log(Status.INFO,
				"<b>ServerHeader2</b>" + "<pre>" + serverHeader2 + "</pre>");
		// Get cookies
		Cookies cookies = response.getDetailedCookies();
		System.out.println("Cookies: " + cookies);
		test.log(Status.INFO,
				"<b>Cookies</b>" + "<pre>" + cookies + "</pre>");
	}
}